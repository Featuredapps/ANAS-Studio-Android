package com.anasgdxj.studio;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.*;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;
import android.widget.EditText;
import android.widget.Toast;
import android.graphics.Bitmap;
import android.util.Base64;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER = 4102;
    private SecureKeyStore keyStore;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        keyStore = new SecureKeyStore(this);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);

        webView.addJavascriptInterface(new NativeBridge(), "AndroidBridge");
        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();
        webView.setWebViewClient(new WebViewClientCompat() {
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equals(uri.getScheme()) && "appassets.androidplatform.net".equals(uri.getHost())) return false;
                if ("https".equals(uri.getScheme()) && ("generativelanguage.googleapis.com".equals(uri.getHost()) ||
                    "fonts.googleapis.com".equals(uri.getHost()) || "fonts.gstatic.com".equals(uri.getHost()) ||
                    "cdn.tailwindcss.com".equals(uri.getHost()))) return false;
                return true;
            }
            @Override public void onPageStarted(WebView view, String url, Bitmap icon) {
                if (!url.startsWith("https://appassets.androidplatform.net/assets/")) {
                    view.stopLoading();
                    view.loadUrl("https://appassets.androidplatform.net/assets/index.html");
                }
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("audio/*");
                startActivityForResult(Intent.createChooser(intent, "اختر ملفاً صوتياً"), FILE_CHOOSER);
                return true;
            }
        });
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(i);
            } catch (Exception e) { Toast.makeText(this, "تعذر فتح رابط التنزيل", Toast.LENGTH_SHORT).show(); }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && fileCallback != null) {
            Uri[] result = (resultCode == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else new AlertDialog.Builder(this).setMessage("هل تريد إغلاق ANAS Studio؟")
            .setNegativeButton("إلغاء", null).setPositiveButton("خروج", (d,w) -> finish()).show();
    }

    private class NativeBridge {
        @JavascriptInterface public String getGeminiApiKey() { return keyStore.get(); }

        @JavascriptInterface public void configureApiKey() {
            runOnUiThread(() -> {
                EditText input = new EditText(MainActivity.this);
                input.setSingleLine(true);
                input.setHint("AIza...");
                input.setInputType( android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
                String existing = keyStore.get();
                if (existing != null) input.setText(existing);
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("مفتاح Gemini API")
                    .setMessage("أدخل مفتاحك الشخصي. سيُحفظ مشفراً على هذا الجهاز.")
                    .setView(input)
                    .setNegativeButton("إلغاء", null)
                    .setNeutralButton("حذف المفتاح", (d,w) -> { keyStore.clear(); toast("تم حذف المفتاح من الجهاز"); })
                    .setPositiveButton("حفظ", (d,w) -> {
                        String value = input.getText().toString().trim();
                        if (value.length() < 20) { toast("المفتاح غير صالح أو قصير"); return; }
                        try { keyStore.save(value); toast("تم حفظ مفتاح Gemini بأمان"); }
                        catch (Exception e) { toast("تعذر حفظ المفتاح"); }
                    }).show();
            });
        }

        @JavascriptInterface public void saveBase64File(String base64, String mime, String name) {
            if (base64 == null || base64.length() > 180_000_000) { toast("حجم الملف أكبر من الحد المسموح"); return; }
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                String safeName = name == null ? "anas_export.bin" : name.replaceAll("[^A-Za-z0-9._-]", "_");
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName);
                    values.put(MediaStore.MediaColumns.MIME_TYPE, mime == null ? "application/octet-stream" : mime);
                    boolean isVideo = mime != null && mime.startsWith("video/");
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH, (isVideo ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_MUSIC) + "/ANAS Studio");
                    Uri collection = isVideo ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                    Uri uri = getContentResolver().insert(collection, values);
                    if (uri == null) throw new Exception("MediaStore insert failed");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) { out.write(bytes); }
                }
                toast("تم حفظ الملف في مجلد Movies/ANAS Studio");
            } catch (Exception e) { toast("فشل حفظ الملف: " + e.getMessage()); }
        }
    }

    private void toast(String msg) { runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show()); }

    @Override protected void onDestroy() {
        if (webView != null) { webView.removeJavascriptInterface("AndroidBridge"); webView.destroy(); }
        super.onDestroy();
    }
}
