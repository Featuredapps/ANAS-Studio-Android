package com.anasgdxj.studio;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.ByteBuffer;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

final class SecureKeyStore {
    private static final String STORE = "anas_secure_store";
    private static final String ALIAS = "anas_gemini_aes_key";
    private final SharedPreferences prefs;
    SecureKeyStore(Context c) { prefs = c.getSharedPreferences(STORE, Context.MODE_PRIVATE); }

    private SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(ALIAS)) return (SecretKey) ks.getKey(ALIAS, null);
        KeyGenerator gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build());
        return gen.generateKey();
    }

    synchronized void save(String value) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key());
        byte[] encrypted = cipher.doFinal(value.getBytes("UTF-8"));
        ByteBuffer b = ByteBuffer.allocate(4 + cipher.getIV().length + encrypted.length);
        b.putInt(cipher.getIV().length); b.put(cipher.getIV()); b.put(encrypted);
        prefs.edit().putString("gemini_key", Base64.encodeToString(b.array(), Base64.NO_WRAP)).apply();
    }

    synchronized String get() {
        try {
            String raw = prefs.getString("gemini_key", null);
            if (raw == null) return "";
            ByteBuffer b = ByteBuffer.wrap(Base64.decode(raw, Base64.NO_WRAP));
            byte[] iv = new byte[b.getInt()]; b.get(iv);
            byte[] encrypted = new byte[b.remaining()]; b.get(encrypted);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(encrypted), "UTF-8");
        } catch (Exception e) { return ""; }
    }

    synchronized void clear() {
        prefs.edit().remove("gemini_key").apply();
        try { KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null); ks.deleteEntry(ALIAS); } catch (Exception ignored) {}
    }
}
